"""Explicit cumulative wall allocation over an unchanged original owner.

The caller holds the producer's ORIGINAL ``owned_directory`` lock throughout
admission and execution. This module never creates an owner, grant, or clock.
Original numerical import paths must already be configured by the supervisor.
"""
from copy import deepcopy
from datetime import datetime, timedelta
from hashlib import sha256
import fcntl
import json
import math
import os
from pathlib import Path
import resource
from time import monotonic, process_time, time

from mixed_material_driver_support import (
    ContinuationBudget, check_loaded_sources, owned_tree)
from substrate_framework.streamed_material_state import file_binding

__all__ = ['admit_allocation', 'create_budget']

_SCHEMA = 'P254-original-source-cumulative-allocation-v1'
_SCOPE = 'same-original-source-physical-step-continuation'
_CAP_KEYS = {'max_actions', 'max_seconds', 'max_output_bytes',
             'max_memory_bytes', 'worker_memory_bytes'}
_GRANT_KEYS = {'schema', 'authorized', 'scope', 'original_owner',
               'original_started_unix', 'original_caps', 'cpus',
               'additional_seconds', 'cumulative_max_seconds',
               'cumulative_deadline_unix', 'issued_at', 'decision'}
_SIGNED_MAX = (1 << 63)-1


def _same(left, right):
    """JSON equality that does not silently equate bool/int/float values."""
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return (left.keys() == right.keys()
                and all(_same(value, right[key]) for key, value in left.items()))
    if isinstance(left, list):
        return len(left) == len(right) and all(map(_same, left, right))
    return left == right


def _finite(value, label, *, positive=False):
    if type(value) not in (int, float):
        raise ValueError(label+' must be a native finite JSON number')
    try:
        valid = math.isfinite(value)
    except OverflowError:
        valid = False
    if not valid or (positive and value <= 0):
        raise ValueError(label+' must be finite'+(' and positive' if positive else ''))
    return value


def _json_pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate JSON authority/evidence field: '+key)
        value[key] = item
    return value


def _invalid_constant(value):
    raise ValueError('nonfinite JSON authority/evidence value: '+value)


def _check_json_numbers(value):
    if isinstance(value, float):
        _finite(value, 'JSON authority/evidence number')
    elif isinstance(value, dict):
        for item in value.values():
            _check_json_numbers(item)
    elif isinstance(value, list):
        for item in value:
            _check_json_numbers(item)


def _read_json(path):
    value = json.loads(Path(path).read_text(), object_pairs_hook=_json_pairs,
                       parse_constant=_invalid_constant)
    _check_json_numbers(value)
    return value


def _plain_path(path):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError('an absolute original path is required: '+str(path))
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError('authority/owned path cannot traverse a symlink: '+str(path))
    if str(path) != str(path.resolve()):
        raise ValueError('authority/owned path must be canonical: '+str(path))
    return path


def _digest(value, label):
    if (type(value) is not str or len(value) != 64
            or any(c not in '0123456789abcdef' for c in value)):
        raise ValueError(label+' must be an explicit lowercase SHA256')
    return value


def _binding(binding):
    if (type(binding) is not dict or set(binding) != {'path', 'bytes', 'sha256'}
            or type(binding['path']) is not str
            or type(binding['bytes']) is not int or binding['bytes'] < 0):
        raise ValueError('an exact native path/int-bytes/SHA256 binding is required')
    path = _plain_path(binding['path'])
    _digest(binding['sha256'], 'binding sha256')
    if not path.is_file():
        raise ValueError('missing bound authority/source: '+str(path))
    actual = file_binding(path)
    if not _same(actual, binding):
        raise ValueError('authenticated authority/source bytes differ: '+str(path))
    return actual


def _bound_json(binding):
    actual = _binding(binding)
    value = _read_json(actual['path'])
    # Parsing and hashing must describe the same retained bytes.
    _binding(actual)
    if type(value) is not dict:
        raise ValueError('authority must be a JSON object: '+actual['path'])
    return actual, value


def _utc(value):
    if type(value) is not str or not value.strip():
        raise ValueError('issued_at requires an explicit UTC timestamp')
    try:
        stamp = datetime.fromisoformat(value[:-1]+'+00:00' if value.endswith('Z') else value)
    except ValueError as error:
        raise ValueError('issued_at requires an explicit UTC timestamp') from error
    if stamp.tzinfo is None or stamp.utcoffset() != timedelta(0):
        raise ValueError('issued_at must explicitly specify UTC')

def _ledger(directory, max_actions, *, prefix=None):
    """Validate EVERY original pre-admission record, without repairing anything."""
    path = _plain_path(directory/'action-admissions.bin')
    lock_path = _plain_path(directory/'action-admissions.lock')
    if not path.is_file() or not lock_path.is_file():
        raise ValueError('continuation requires the existing original action ledger and lock')
    previous = (0, 0)
    digest = sha256()
    prefix_digest = sha256().hexdigest() if prefix is not None and not prefix['bytes'] else None
    with lock_path.open('rb') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_SH)
        with path.open('rb') as stream:
            while True:
                record = stream.read(ContinuationBudget.RECORD.size)
                if not record:
                    break
                if len(record) != ContinuationBudget.RECORD.size:
                    raise ValueError('incomplete original durable action ledger')
                actions, columns = ContinuationBudget.RECORD.unpack(record)
                if (actions != previous[0]+1 or columns <= previous[1]
                        or actions > max_actions or columns > _SIGNED_MAX):
                    raise ValueError('damaged/noncumulative original action ledger')
                previous = actions, columns
                digest.update(record)
                if prefix is not None and actions == prefix['hamiltonian_actions']:
                    prefix_digest = digest.hexdigest()
    if prefix is not None and (
            previous[0] < prefix['hamiltonian_actions']
            or prefix_digest != prefix['sha256']):
        raise ValueError('original admitted action ledger prefix changed or was truncated')
    return dict(path=str(path), bytes=previous[0]*ContinuationBudget.RECORD.size,
                sha256=digest.hexdigest(), hamiltonian_actions=previous[0],
                action_columns=previous[1])




def _retained_ledger_check(directory, ledger, started):
    """Reject a valid-looking truncated ledger contradicted by retained evidence.

    No ledger format can detect deletion of a wholly unreceipted terminal suffix.
    Never infer the lost admissions or manufacture compensating action charges.
    """
    for root in ('invocations', 'steps', 'scientific-work', 'baseline-frame-work'):
        base = directory/root
        if not base.exists():
            continue
        for path in base.rglob('*.json'):
            selected = (
                (root == 'invocations' and path.name == 'receipt.json')
                or (root == 'steps' and path.name == 'complete.json')
                or (root in ('scientific-work', 'baseline-frame-work')
                    and path.name.startswith('execution-')))
            if not selected:
                continue
            _plain_path(path)
            record = _read_json(path)
            if type(record) is not dict:
                raise ValueError('damaged retained budget evidence: '+str(path))
            budget = record.get('budget')
            if budget is None:
                continue
            if type(budget) is not dict:
                raise ValueError('damaged retained budget snapshot: '+str(path))
            for key in ('hamiltonian_actions', 'action_columns'):
                count = budget.get(key)
                if type(count) is not int or not 0 <= count <= ledger[key]:
                    raise ValueError('original ledger contradicts retained '+key+': '+str(path))
            if ('original_started_unix' in budget
                    and not _same(budget['original_started_unix'], started)):
                raise ValueError('retained budget changed original clock: '+str(path))


def admit_allocation(producer_directory: Path, original_owner_sha256: str,
                     grant_binding: dict) -> dict:
    """Read-only admission under the caller-held original owner.lock.

    The supplied grant digest is external authority, NOT authorization generated
    by this program. No cap except cumulative wall time can differ from owner.
    """
    directory = _plain_path(Path(producer_directory).absolute())
    if not directory.is_dir():
        raise ValueError('original producer directory is missing')
    _digest(original_owner_sha256, 'original owner sha256')
    owner_path = _plain_path(directory/'owner.json')
    owner_binding = file_binding(owner_path)
    if owner_binding['sha256'] != original_owner_sha256:
        raise ValueError('original owner digest differs')
    owner_binding, owner = _bound_json(owner_binding)
    request = owner.get('request')
    if (type(request) is not dict
            or request.get('schema') != 'P254-native-mixed-q-material-v1-owner'):
        raise ValueError('original Native mixed owner request is required')
    started = _finite(owner.get('started_unix'), 'original started_unix', positive=True)
    if started > time():
        raise ValueError('original start lies in the future; no freshness-reset clock admitted')
    original_caps = request.get('caps')
    if type(original_caps) is not dict or set(original_caps) != _CAP_KEYS:
        raise ValueError('exact original Native budget caps are required')
    for key in _CAP_KEYS-{'max_seconds'}:
        if type(original_caps[key]) is not int or not 0 < original_caps[key] <= _SIGNED_MAX:
            raise ValueError('original '+key+' must be a positive native signed-range integer')
    original_seconds = _finite(original_caps['max_seconds'], 'original max_seconds', positive=True)
    if original_caps['worker_memory_bytes'] > original_caps['max_memory_bytes']:
        raise ValueError('original worker memory cap exceeds aggregate cap')
    cpus = request.get('cpus')
    if (type(cpus) is not list or not cpus
            or any(type(cpu) is not int or cpu not in range(6, 11) for cpu in cpus)
            or len(set(cpus)) != len(cpus)):
        raise ValueError('original explicit unique Native CPUs6-10 are required')
    sources = request.get('source_bindings')
    if type(sources) is not list or not sources:
        raise ValueError('complete original numerical source bindings are required')
    paths = set()
    for binding in sources:
        actual = _binding(binding)
        if actual['path'] in paths:
            raise ValueError('duplicate original numerical source binding')
        paths.add(actual['path'])
    check_loaded_sources(sources)
    actual_grant_binding, grant = _bound_json(grant_binding)
    if not _GRANT_KEYS <= grant.keys():
        raise ValueError('grant is missing explicit cumulative-allocation schema fields')
    if (grant['schema'] != _SCHEMA or grant['authorized'] is not True
            or grant['scope'] != _SCOPE):
        raise ValueError('explicit authorized same-original-source cumulative grant required')
    for key, expected in (('original_owner', owner_binding), ('original_started_unix', started),
                          ('original_caps', original_caps), ('cpus', cpus)):
        if not _same(grant[key], expected):
            raise ValueError('grant drifts from original '+key)
    additional = _finite(grant['additional_seconds'], 'additional_seconds', positive=True)
    if additional > 21600:
        raise ValueError('additional wall allocation exceeds the explicit six-hour ceiling')
    cumulative = _finite(grant['cumulative_max_seconds'], 'cumulative_max_seconds', positive=True)
    deadline = _finite(grant['cumulative_deadline_unix'], 'cumulative_deadline_unix', positive=True)
    original_deadline = _finite(started+original_seconds, 'original deadline', positive=True)
    if (cumulative != original_seconds+additional or cumulative <= original_seconds
            or deadline != started+cumulative or deadline <= original_deadline):
        raise ValueError('cumulative cap/deadline must exactly extend the ORIGINAL clock')
    _utc(grant['issued_at'])
    if type(grant['decision']) is not str or not grant['decision'].strip():
        raise ValueError('grant requires explicit nonempty Root decision identifier/evidence')
    ledger = _ledger(directory, original_caps['max_actions'])
    _retained_ledger_check(directory, ledger, started)
    caps = dict(original_caps, max_seconds=cumulative)
    return deepcopy(dict(producer_directory=str(directory), owner_binding=owner_binding,
        owner=owner, original_request=request, numerical_sources=sources,
        grant_binding=actual_grant_binding, grant=grant,
        original_deadline_unix=original_deadline, cumulative_max_seconds=cumulative,
        cumulative_deadline_unix=deadline, caps=caps))


def _historical_evidence(directory, existing):
    """Compact references, not a second sum of overlapping worker/stage costs.

    Snapshot is embedded in bounded original QWork terminal receipts. Keep the
    inventory compact; the digest binds the sorted full list of retained JSON
    byte bindings, reproducible from these original namespace roots.
    """
    kinds = {}
    for name in sorted(existing):
        path = Path(name)
        relative = path.relative_to(directory)
        if path.suffix != '.json':
            continue
        if relative.parts[0] == 'invocations' and path.name == 'receipt.json':
            kind = 'invocation_receipts'
        elif relative.parts[0] in ('scientific-work', 'baseline-frame-work') and path.name == 'complete.json':
            kind = 'qwork_item_receipts'
        elif relative.parts[0] == 'steps' and path.name == 'complete.json':
            kind = 'stage_receipts'
        elif relative.parts[0] == 'steps' and path.name == 'transition.json':
            kind = 'edge_transition_receipts'
        else:
            continue
        binding = file_binding(path)
        # Preserve actual immutable references even where measurements are absent.
        group = kinds.setdefault(kind, dict(count=0, bytes=0, bindings=[]))
        group['count'] += 1
        group['bytes'] += binding['bytes']
        group['bindings'].append(binding)
    for group in kinds.values():
        bindings = group.pop('bindings')
        group['binding_inventory_sha256'] = sha256(json.dumps(
            bindings, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    return dict(namespace=str(directory), retained_at_budget_creation=kinds,
        inventory_encoding='SHA256 of sorted-by-path native binding list; compact sorted-key JSON, separators comma/colon',
        interpretation='retained original invocation/stage/QWork/transition evidence is historical, never new compute; categories may overlap and are not summed',
        missing_measurements='no CPU, wall, RSS or physical I/O estimate is invented for unreceipted interrupted work; durable action admissions alone remain exact',
        current_worker_measurements='original newly published QWork/transition receipts measure current work; their recovery-only measurements do not replace original transition costs')


class _CumulativeContinuationBudget(ContinuationBudget):
    def __init__(self, admission):
        self._admission = deepcopy(admission)
        self._invocation_started = monotonic()
        self._parent_cpu_started = process_time()
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        self._children_cpu_started = usage.ru_utime+usage.ru_stime
        self._invocation_pid = os.getpid()
        directory = Path(admission['producer_directory'])
        caps = admission['caps']
        self._initial_ledger = _ledger(directory, caps['max_actions'])
        existing = owned_tree(directory)
        self._historical_costs = _historical_evidence(directory, existing)
        super().__init__(directory, started_at=admission['owner']['started_unix'],
            max_actions=caps['max_actions'], max_seconds=caps['max_seconds'],
            max_bytes=caps['max_output_bytes'], max_memory_bytes=caps['max_memory_bytes'],
            worker_memory_bytes=caps['worker_memory_bytes'], existing_bytes=sum(existing.values()))
        if (self.actions != self._initial_ledger['hamiltonian_actions']
                or self.columns != self._initial_ledger['action_columns']):
            raise ValueError('original action ledger changed during budget creation')

    def snapshot(self):
        value = super().snapshot()
        authority = self._admission
        ledger = _ledger(Path(authority['producer_directory']), self.max_actions,
                         prefix=self._initial_ledger)
        value.update(hamiltonian_actions=ledger['hamiltonian_actions'],
            action_columns=ledger['action_columns'], action_ledger=ledger,
            original_allocation=dict(owner=deepcopy(authority['owner_binding']),
                caps=deepcopy(authority['original_request']['caps']),
                cpus=deepcopy(authority['original_request']['cpus']),
                started_unix=self.started_at, deadline_unix=authority['original_deadline_unix']),
            cumulative_allocation=dict(grant=deepcopy(authority['grant_binding']),
                schema=authority['grant']['schema'], decision=authority['grant']['decision'],
                issued_at=authority['grant']['issued_at'],
                additional_seconds=authority['grant']['additional_seconds'],
                caps=deepcopy(authority['caps']),
                deadline_unix=authority['cumulative_deadline_unix'],
                authority='explicit separate additional wall allocation; all other original caps/science/CPUs unchanged'),
            storage_counter_scope='live bytes include the remeasured retained tree; inherited allocation/write/retirement counters and RSS observations describe this budget instance only, not whole-run cumulative I/O or peak RSS; original immutable cost evidence remains separate',
            current_invocation=self._current_costs(ledger),
            historical_costs=deepcopy(self._historical_costs))
        return value

    def _current_costs(self, ledger):
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        return dict(measured_in_pid=os.getpid(), budget_parent_pid=self._invocation_pid,
            budget_lifetime_wall_seconds=monotonic()-self._invocation_started,
            parent_cpu_seconds_since_budget_creation=(process_time()-self._parent_cpu_started
                if os.getpid() == self._invocation_pid else None),
            reaped_child_cpu_seconds_since_budget_creation=(
                usage.ru_utime+usage.ru_stime-self._children_cpu_started
                if os.getpid() == self._invocation_pid else None),
            process_lifetime_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
            watchdog_observed_peak_aggregate_rss_bytes=self.peak_aggregate_rss,
            admitted_action_delta=ledger['hamiltonian_actions']-self._initial_ledger['hamiltonian_actions'],
            admitted_column_delta=ledger['action_columns']-self._initial_ledger['action_columns'],
            measurement_scope='wall is budget lifetime, not a reset allocation clock; CPU deltas are parent and already-reaped children only; process peak RSS is lifetime high-water, not additive; driver records entire invocation separately; running/interrupted unreceipted worker CPU and physical I/O are not inferred')


def create_budget(admission: dict) -> ContinuationBudget:
    """Reauthenticate admission, then reuse original start, ledger and non-time caps."""
    if type(admission) is not dict:
        raise ValueError('authenticated admission dictionary required')
    fresh = admit_allocation(Path(admission['producer_directory']),
        admission['owner_binding']['sha256'], admission['grant_binding'])
    if not _same(admission, fresh):
        raise ValueError('admitted owner/grant/source/cap/start authority changed')
    return _CumulativeContinuationBudget(fresh)
