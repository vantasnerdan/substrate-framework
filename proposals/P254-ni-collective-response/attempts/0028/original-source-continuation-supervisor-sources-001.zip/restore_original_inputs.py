"""Restore the frozen mixed driver's original request, without new physics inputs."""
from pathlib import Path
import json


def _canonical_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def restore_original_inputs(driver, admission, output):
    """Return original arguments, metadata and sources after exact request comparison.

    The caller must already hold the original producer's owner.lock. In
    particular, the allocation's cumulative wall allowance is NOT substituted
    into these arguments or the original owner request.
    """
    request = admission['original_request']
    if request.get('schema') != driver.SCHEMA+'-owner':
        raise ValueError('the original Native mixed owner schema is required')
    directory = Path(admission['producer_directory'])
    argv = ['--case', request['case'], '--directory', str(directory),
            '--output', str(output), '--mode', 'forward', '--resume']
    for option, key in (('initialization', 'initialization'), ('history', 'history'),
                        ('execution-proof', 'execution_proof')):
        binding = request[key]
        driver.authenticate(binding)
        argv.extend(('--'+option, binding['path'], '--'+option+'-sha256', binding['sha256']))
    for frame in request['frames']:
        binding = frame['proof']
        driver.authenticate(binding)
        argv.extend(('--frame-admission', binding['path'], binding['sha256']))
    for name in ('q', 'cell', 'cpus'):
        argv.append('--'+name)
        argv.extend(str(value) for value in request[name])
    for name in ('atom', 'axis', 'amplitude', 'time', 'subdivisions', 'block_size'):
        argv.extend(('--'+name.replace('_', '-'), str(request[name])))
    for name, value in request['caps'].items():
        argv.extend(('--'+name.replace('_', '-'), str(value)))
    for name in ('energy', 'retain_endpoints'):
        if request[name] is True:
            argv.append('--'+name.replace('_', '-'))
        elif request[name] is not False:
            raise ValueError('original boolean selection changed: '+name)
    args = driver.parser().parse_args(argv)
    driver.require_arguments(args)
    inputs = driver.metadata_inputs(args)
    # These are exactly the original main's numerical dependency seeds. The
    # orchestration sources deliberately never enter this scientific closure.
    seeds = driver.existing_dependencies()+[driver.file_binding(driver.HERE/name) for name in (
        'run_mixed_q_material.py', 'mixed_material_driver_support.py', 'mixed_material_dynamics.py',
        'mixed_response_rk4.py', 'mixed_response_edge_transition.py', 'mixed_response_storage.py',
        'mixed_payload_output.py', 'local_pulse_energy.py',
        'mixed_material_edge.py', 'mixed_material_moments.py', 'mixed_coordinate_response.py',
        'mixed_frame_response.py', 'mixed_physical_field_dyads.py', 'actual_frame_cache_io.py',
        'actual_frame_cache_provenance.py', 'reuse_actual_baseline_frames.py')]
    if args.energy:
        seeds.append(driver.file_binding(driver.HERE/'mixed_material_energy.py'))
    sources = driver.source_closure(seeds)
    restored = driver.canonical(dict(schema=driver.SCHEMA+'-owner', case=args.case,
        initialization=inputs['initialization'], history=inputs['history_binding'],
        execution_proof=inputs['execution_binding'], normalization=inputs['normalization'],
        frames=inputs['frame_metadata'], q=args.q, atom=args.atom, axis=args.axis,
        frame_requirements=inputs['frame_requirements'], amplitude=args.amplitude,
        cell=args.cell, time=args.time, subdivisions=args.subdivisions,
        cpus=args.cpus, caps=driver.caps(args), block_size=args.block_size,
        energy=args.energy, retain_endpoints=args.retain_endpoints,
        source_bindings=sources, inputs=inputs['borrowed']))
    if _canonical_bytes(restored) != _canonical_bytes(request):
        raise ValueError('original canonical owner/source/input/selection/caps request differs')
    if _canonical_bytes(sources) != _canonical_bytes(admission['numerical_sources']):
        raise ValueError('restored numerical source closure differs from the original allocation')
    driver.check_loaded_sources(sources)
    # Original main line 469 expands this ONLY AFTER freezing the owner request.
    # Keeping this expansion is essential to initial and QWork scientific identity.
    inputs['borrowed'] = driver.nested_bindings(inputs['borrowed'], sources)
    return args, inputs, sources
