#!/usr/bin/env python3
"""Continue the same frozen Native mixed owner under an external cumulative grant.

No invocation of this program creates production authority. The original producer
must first release its existing owner.lock. Scientific selection, CPU allocation,
non-time caps, numerical sources, start and action ledger are restored verbatim.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import sys
from time import perf_counter, process_time, time
from uuid import uuid4

HERE = Path(__file__).resolve().parent
ORCHESTRATION_ROOT = HERE.parents[3]
NUMERICAL_ROOT = Path('/home/administrator/projects/substrate-ni-collective')
ATTEMPT = NUMERICAL_ROOT/'proposals/P254-ni-collective-response/attempts/0028'
RUNTIME_PACKAGES = Path('/home/administrator/.cache/dft/p254-a28-runtime')
SCHEMA = 'P254-original-source-mixed-continuation-v1'
SUPERVISOR_FILES = ('run_original_mixed_continuation.py', 'restore_original_inputs.py',
                    'continuation_allocation.py')
PROTECTED_TREES = frozenset(('initial', 'scientific-work', 'baseline-frame-work', 'steps',
    'step-receipts', 'energy', 'endpoint-retirements', 'invocations'))


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument('--producer', type=Path, required=True)
    result.add_argument('--producer-owner-sha256', required=True)
    result.add_argument('--allocation', type=Path, required=True)
    result.add_argument('--allocation-sha256', required=True)
    result.add_argument('--output', type=Path, required=True)
    return result


def _binding(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        before = os.fstat(stream.fileno())
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
        after = os.fstat(stream.fileno())
    if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
            after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError('source/input changed while being bound: '+str(path))
    return dict(path=str(path), bytes=after.st_size, sha256=digest.hexdigest())


def _supervisor_sources():
    return [_binding(HERE/name) for name in sorted(SUPERVISOR_FILES)]


def _check_supervisor_sources(bindings):
    expected = {binding['path']: binding for binding in bindings}
    for module in tuple(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename:
            path = Path(filename).resolve()
            if path.is_relative_to(ORCHESTRATION_ROOT) and path.suffix in ('.py', '.pyc'):
                if str(path) not in expected:
                    raise ValueError('unbound orchestration runtime source: '+str(path))
    for binding in bindings:
        if _binding(binding['path']) != binding:
            raise ValueError('supervisor source changed: '+binding['path'])


def _paths(args):
    # Inspect lexical parents before resolve, so a symlink cannot disappear from
    # the admission check. Never create a missing producer or a replacement lock.
    for path in (args.producer.absolute(), args.output.absolute()):
        for part in (path, *path.parents):
            if part.is_symlink():
                raise ValueError('producer/output cannot traverse a symlink: '+str(part))
    producer, output = args.producer.resolve(), args.output.resolve()
    if (not producer.is_dir() or not (producer/'owner.json').is_file()
            or not (producer/'owner.lock').is_file()):
        raise ValueError('existing original producer, owner.json and owner.lock required')
    relative = output.relative_to(producer)
    if (not relative.parts or output.suffix != '.json'
            or relative.parts[0] in PROTECTED_TREES or output.name == 'owner.json'):
        raise ValueError('output must be a new JSON receipt outside original scientific/owner paths')
    if output.exists() or output.is_symlink():
        raise FileExistsError('immutable output already exists: '+str(output))
    return producer, output


class _ReservedJSON:
    """Preallocate on the destination filesystem, then publish without overwrite.

    Separate terminal/output slots keep both publications possible after ENOSPC
    or a budget exception. Only these newly created private files are rewritten;
    immutable destinations are installed using link's exclusive-create semantics.
    """
    def __init__(self, path, capacity):
        self.path, self.capacity = Path(path), capacity
        self.fd = os.open(self.path, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            os.posix_fallocate(self.fd, 0, capacity)
            os.fsync(self.fd)
        except BaseException:
            os.close(self.fd)
            self.fd = None
            self.path.unlink()
            raise

    def publish(self, target, value, driver):
        payload = (json.dumps(value, indent=2, allow_nan=False)+'\n').encode()
        if len(payload) > self.capacity:
            raise RuntimeError('terminal JSON exceeds its pre-work reserved capacity')
        target = Path(target)
        offset = 0
        while offset < len(payload):
            written = os.pwrite(self.fd, payload[offset:], offset)
            if written <= 0:
                raise OSError('short reserved terminal write')
            offset += written
        os.ftruncate(self.fd, len(payload))
        os.fsync(self.fd)
        os.link(self.path, target)
        driver.sync_directory(target.parent)
        os.close(self.fd)
        self.fd = None
        self.path.unlink()
        driver.sync_directory(self.path.parent)
        return driver.file_binding(target)

    def grow(self, capacity):
        if capacity > self.capacity:
            os.posix_fallocate(self.fd, 0, capacity)
            os.fsync(self.fd)
            self.capacity = capacity

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None
        # This object only ever owns its unique newly created reservation.
        if self.path.exists():
            self.path.unlink()


@contextmanager
def _catchable_termination():
    parent = os.getpid()
    signals = (signal.SIGTERM, signal.SIGHUP, signal.SIGQUIT)
    previous = {number: signal.getsignal(number) for number in signals}
    def terminate(number, frame):
        if os.getpid() != parent:
            signal.signal(number, signal.SIG_DFL)
            os.kill(os.getpid(), number)
        raise SystemExit(128+number)
    for number in signals:
        signal.signal(number, terminate)
    try:
        yield
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


def _historical_scope(directory, invocation, driver):
    terminal, missing = [], []
    for path in sorted((directory/'invocations').glob('*')):
        if not path.is_dir() or path.name == invocation:
            continue
        receipt = path/'receipt.json'
        if receipt.is_file():
            terminal.append(driver.file_binding(receipt))
        else:
            missing.append(str(path))
    return dict(invocation_receipts=terminal, invocations_without_terminal_receipt=missing,
        retained_cost_reference_roots=[str(directory/name) for name in (
            'scientific-work', 'baseline-frame-work', 'steps')],
        scope='preexisting immutable Native/QWork/stage receipts, not current-invocation compute',
        unmeasured='no reconstructed historical CPU, peak RSS or physical device I/O; '
                   'interrupted work may lack terminal measurements; durable admissions remain charged')


def _physical_endpoint_observed(metadata, selected_time, model_identity):
    return (metadata.get('time') == selected_time
        and metadata.get('identity') == model_identity
        and metadata.get('kind') == 'mixed-rk4-physical-endpoint'
        and metadata.get('provenance', {}).get('physical_endpoint') is True)


def _owned_run(cli, directory, output, driver, supervisor, clocks):
    started, cpu_started, started_unix, children_before = clocks
    invocation = uuid4().hex
    invocation_directory = directory/'invocations'/invocation
    receipt = invocation_directory/'receipt.json'
    result = dict(schema=SCHEMA, status='error', invocation=invocation,
        invocation_started_unix=started_unix,
        invocation_started_at=datetime.fromtimestamp(started_unix, timezone.utc).isoformat(),
        mode='forward', production_authorization_issued_by_this_program=False,
        supervisor_source_bindings=supervisor,
        supervisor_source_scope='all Python orchestration sources under '+str(ORCHESTRATION_ROOT)+
            '; independently bound, never included in original numerical/cache identities',
        numerical_source_scope='the complete original owner numerical closure; unchanged',
        scientific_scope='same original selected-q raw coherent mixed timestep; not a new '
            'trajectory, whole-q reconstruction, noise, heat or finite-dose energy',
        numerical_accuracy_certified=False,
        termination_limits='catchable owned exits retain terminal receipts; SIGKILL/host loss '
            'cannot promise terminal publication; original owner/ledger/cache survive')
    budget = admission = args = None
    sources = None
    baseline_actions = baseline_columns = None
    terminal_slot = output_slot = None
    try:
        if output.exists() or output.is_symlink():
            raise FileExistsError('immutable output already exists: '+str(output))
        owner_binding = _binding(directory/'owner.json')
        if owner_binding['sha256'] != cli.producer_owner_sha256:
            raise ValueError('explicit original owner digest differs')
        result['owner'] = owner_binding
        # Only this new invocation's paths are authored. Reserve before metadata,
        # allocation construction or any Native factory. The full slots are
        # subsequently included in create_budget's owned-tree remeasurement.
        invocation_directory.mkdir(parents=True, exist_ok=False)
        output.parent.mkdir(parents=True, exist_ok=True)
        capacity = 4*owner_binding['bytes']+1024**2
        terminal_slot = _ReservedJSON(invocation_directory/'.terminal-reserved', capacity)
        output_slot = _ReservedJSON(output.with_name('.'+output.name+'.'+invocation+'.reserved'), capacity)
        result['terminal_reservation'] = dict(bytes_per_publication=capacity,
            physical='posix_fallocate on each destination filesystem; exclusive link publication',
            accounting='both full slots are charged by the cumulative budget before physics')
        lifecycle = dict(schema=SCHEMA+'-lifecycle', invocation=invocation,
            status='started; external allocation not yet admitted',
            started_unix=started_unix, original_owner=owner_binding,
            requested_allocation=dict(path=str(cli.allocation.resolve()), sha256=cli.allocation_sha256),
            supervisor_source_bindings=supervisor, output=str(output),
            original_namespace=str(directory), terminal_receipt=str(receipt))
        result['lifecycle_receipt'] = driver.exact_publish(
            invocation_directory/'lifecycle.json', lifecycle, None)
        result['historical_evidence'] = _historical_scope(directory, invocation, driver)
        import continuation_allocation as allocation_api
        import restore_original_inputs as restore
        for module, name in ((allocation_api, 'continuation_allocation.py'),
                             (restore, 'restore_original_inputs.py')):
            if Path(module.__file__).resolve() != HERE/name:
                raise ValueError('unexpected supervisor module import: '+name)
        _check_supervisor_sources(supervisor)
        grant_binding = _binding(cli.allocation)
        if grant_binding['sha256'] != cli.allocation_sha256:
            raise ValueError('explicit allocation digest differs')
        admission = allocation_api.admit_allocation(directory, cli.producer_owner_sha256, grant_binding)
        result.update(allocation_authorized=True, allocation_binding=admission['grant_binding'],
            allocation=admission['grant'], source_bindings=admission['numerical_sources'],
            original_allocation=dict(owner=admission['owner_binding'],
                started_unix=admission['owner']['started_unix'],
                started_at=admission['owner']['started_at'],
                caps=admission['original_request']['caps'],
                cpus=admission['original_request']['cpus'],
                deadline_unix=admission['original_deadline_unix']),
            cumulative_allocation=dict(caps=admission['caps'],
                max_seconds=admission['cumulative_max_seconds'],
                deadline_unix=admission['cumulative_deadline_unix']))
        budget = allocation_api.create_budget(admission)
        baseline_actions, baseline_columns = budget.actions, budget.columns
        result['prior_action_ledger'] = driver.file_binding(budget.ledger)
        # Original convention reserves all remaining durable ledger growth too.
        budget.reserve(max(0, admission['caps']['max_actions']*budget.RECORD.size
                           -budget.ledger.stat().st_size))
        with driver.watchdog(budget):
            args, inputs, sources = restore.restore_original_inputs(driver, admission, output)
            result.update(case=args.case, q=args.q, selected_time=args.time,
                subdivisions=args.subdivisions, cpus=args.cpus, blas_threads=1,
                whole_spatial_reconstruction=False, required_q_for_whole_local=64,
                initialization=inputs['initialization'], history=inputs['history_binding'],
                history_execution_proof=inputs['execution_binding'],
                normalization=inputs['normalization'], borrowed_inputs=inputs['borrowed'],
                canonical_original_request_verified=True)
            existing = driver.owned_tree(directory)
            result['resource_plan'] = driver.resource_plan(inputs['shapes'], inputs['steps'],
                inputs['borrowed'], existing=existing, workers=len(args.cpus),
                caps=admission['caps'], history=inputs['history'],
                gamma=bool(driver.np.all(driver.np.asarray(args.q) == 0)),
                retain_endpoints=args.retain_endpoints,
                frame_requirements=inputs['frame_requirements'])
            # Size against the actual restored provenance/plan before entering
            # the factory, not just the owner's initially estimated JSON size.
            required = 4*len(json.dumps(result, allow_nan=False).encode())+8192*len(inputs['steps'])+1024**2
            if required > capacity:
                budget.reserve(2*(required-capacity))
                terminal_slot.grow(required)
                output_slot.grow(required)
                result['terminal_reservation']['bytes_per_publication'] = required
            _check_supervisor_sources(supervisor)
            driver.check_loaded_sources(sources)
            os.sched_setaffinity(0, {args.cpus[0]})
            from threadpoolctl import threadpool_limits
            import threadpoolctl
            result['external_threadpool_control_source'] = driver.file_binding(Path(threadpoolctl.__file__))
            result['runtime'] = dict(python=sys.version, executable=sys.executable,
                external_dependency_scope='original installed Python/numpy/BLAS runtime; '
                    'not additional scientific or orchestration repository sources')
            with threadpool_limits(limits=1):
                # This is the frozen driver itself, including idempotent sparse
                # seed restore, endpoint-chain reuse, and retained RK4/QWork work.
                driver.execute(args, inputs, sources, budget, directory, result)
    except BaseException as error:
        result.update(status='partial' if result.get('final') else 'error',
                      error=type(error).__name__+': '+str(error))
    finally:
        # Do not let repeated catchable termination interrupt reserved publication.
        blocked = signal.pthread_sigmask(signal.SIG_BLOCK,
            {signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT})
        try:
            integrity_errors = []
            checks = [('supervisor', lambda: _check_supervisor_sources(supervisor))]
            if admission is not None:
                checks.extend((('original owner', lambda: driver.authenticate(admission['owner_binding'])),
                               ('allocation', lambda: driver.authenticate(admission['grant_binding'])),
                               ('numerical sources', lambda: driver.check_loaded_sources(
                                   admission['numerical_sources']))))
            for label, check in checks:
                try:
                    check()
                except BaseException as error:
                    integrity_errors.append(label+': '+type(error).__name__+': '+str(error))
            if integrity_errors:
                result['terminal_integrity_errors'] = integrity_errors
                result['status'] = 'partial' if result.get('final') else 'error'
            result['owner_byte_identity_verified'] = admission is not None and not any(
                message.startswith('original owner:') for message in integrity_errors)
            if result.get('final'):
                try:
                    metadata = json.loads(driver.authenticate(result['final']).read_text())
                    physical_complete = (args is not None and _physical_endpoint_observed(
                        metadata, args.time, result.get('model_identity')))
                    result['actual_final_boundary'] = dict(binding=result['final'],
                        time=metadata.get('time'), identity=metadata.get('identity'),
                        requested_physical_endpoint_observed=physical_complete)
                    result['evolution_complete'] = physical_complete
                except BaseException as error:
                    result['final_boundary_error'] = type(error).__name__+': '+str(error)
                    result['status'] = 'partial'
            result['requested_behavior_complete'] = (result['status'] == 'complete'
                and result.get('evolution_complete') is True and not integrity_errors)
            if result['status'] == 'complete' and not result['requested_behavior_complete']:
                result['status'] = 'partial'
            children = resource.getrusage(resource.RUSAGE_CHILDREN)
            current = dict(wall_seconds=perf_counter()-started,
                parent_cpu_seconds=process_time()-cpu_started,
                reaped_children_user_cpu_seconds=children.ru_utime-children_before.ru_utime,
                reaped_children_system_cpu_seconds=children.ru_stime-children_before.ru_stime,
                parent_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
                reaped_child_peak_rss_bytes=children.ru_maxrss*1024,
                scope='this supervisor process and its reaped children only; excludes historical receipts',
                physical_device_io='not measured; logical reservations are not device I/O')
            if budget is not None:
                try:
                    snapshot = budget.snapshot()
                    result['budget'] = snapshot
                    current.update(
                        durable_action_admissions=snapshot['hamiltonian_actions']-baseline_actions,
                        durable_action_columns=snapshot['action_columns']-baseline_columns,
                        cumulative_actions_before=baseline_actions,
                        cumulative_actions_after=snapshot['hamiltonian_actions'],
                        cumulative_columns_before=baseline_columns,
                        cumulative_columns_after=snapshot['action_columns'],
                        peak_aggregate_rss_bytes=snapshot.get('peak_aggregate_rss_bytes'))
                    result['terminal_action_ledger'] = driver.file_binding(budget.ledger)
                except BaseException as error:
                    # A corrupt ledger is still a terminal failure, not a reason
                    # to lose the original physics error or invent action counts.
                    result['terminal_budget_error'] = type(error).__name__+': '+str(error)
                    result['status'] = 'partial' if result.get('final') else 'error'
                    result['requested_behavior_complete'] = False
                    current['durable_action_admissions'] = None
            else:
                result['budget'] = None
                current['durable_action_admissions'] = 0
            result.update(current_invocation=current,
                terminal_at=datetime.now(timezone.utc).isoformat())
            # Once initialized, both slots were physically reserved before any
            # scientific work. Never consult an exhausted budget to publish them.
            if terminal_slot is None:
                invocation_directory.mkdir(parents=True, exist_ok=True)
                capacity = len(json.dumps(result, indent=2, allow_nan=False).encode())+65536
                terminal_slot = _ReservedJSON(invocation_directory/'.terminal-reserved', capacity)
            binding = terminal_slot.publish(receipt, result, driver)
            published = dict(result, invocation_receipt=binding)
            if output_slot is None:
                # Reservation failure cannot have reached a factory. Still use
                # exclusive publication for this owned pre-work refusal.
                output.parent.mkdir(parents=True, exist_ok=True)
                capacity = len(json.dumps(published, indent=2, allow_nan=False).encode())+65536
                output_slot = _ReservedJSON(
                    output.with_name('.'+output.name+'.'+invocation+'.reserved'), capacity)
            output_slot.publish(output, published, driver)
        finally:
            if terminal_slot is not None:
                terminal_slot.close()
            if output_slot is not None:
                output_slot.close()
            signal.pthread_sigmask(signal.SIG_SETMASK, blocked)
    return result


def main(argv=None):
    started, cpu_started, started_unix = perf_counter(), process_time(), time()
    children_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    cli = parser().parse_args(argv)
    try:
        # Imports may read frozen numerical sources but never create bytecode or
        # call Native factories, allocate work, or mutate the producer namespace.
        sys.dont_write_bytecode = True
        supervisor = _supervisor_sources()
        producer, output = _paths(cli)
        for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                    'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
            os.environ[key] = '1'
        sys.path[:0] = [str(NUMERICAL_ROOT/'src'), str(ATTEMPT),
                       str(ATTEMPT.parent/'0025'), str(ATTEMPT.parent/'0024'),
                       str(HERE), str(RUNTIME_PACKAGES)]
        import run_mixed_q_material as driver
        if Path(driver.__file__).resolve() != ATTEMPT/'run_mixed_q_material.py':
            raise ValueError('unexpected original numerical driver import')
        # Lock admission is outside the owned receipt handler. An active owner
        # fails here, before allocation construction, metadata or any factory,
        # and receives no refusal file in somebody else's work namespace.
        with driver.owned_directory(producer, True) as directory:
            with _catchable_termination():
                result = _owned_run(cli, directory, output, driver,
                    supervisor, (started, cpu_started, started_unix, children_before))
        print(json.dumps(dict(schema=SCHEMA, status=result['status'], output=str(output),
            final=result.get('final'), error=result.get('error'),
            requested_behavior_complete=result.get('requested_behavior_complete')), sort_keys=True))
        return 0 if result['requested_behavior_complete'] else 2
    except BaseException as error:
        print(json.dumps(dict(schema=SCHEMA, status='refused',
            error=type(error).__name__+': '+str(error)), sort_keys=True), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
