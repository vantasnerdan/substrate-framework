import sys
from pathlib import Path
ROOT=Path('/home/administrator/projects/substrate-ni-collective')
A=ROOT/'proposals/P254-ni-collective-response/attempts'
sys.path[:0]=[str(ROOT/'src'),str(A/'0028'),str(A/'0025'),str(A/'0024')]
import hashlib,json,multiprocessing as mp,os,signal,tempfile,time
from saved_case_mean_owner import terminal_signals
from mixed_material_driver_support import ContinuationBudget
from run_mixed_q_material import watchdog

def native_block(ready):
    os.write(ready,b'1')
    os.close(ready)
    hashlib.pbkdf2_hmac('sha256',b'owned-worker',b'P254',100_000_000)

with tempfile.TemporaryDirectory(prefix='p254-mean-worker-before-') as directory:
    rd,wr=os.pipe()
    worker=mp.get_context('fork').Process(target=native_block,args=(wr,))
    report={}
    try:
        with terminal_signals():
            worker.start()
            os.close(wr)
            assert os.read(rd,1)==b'1'
            os.close(rd)
            due=time.monotonic()+3
            while int(Path(f'/proc/{worker.pid}/stat').read_text().split()[13]) == 0:
                if time.monotonic()>due: raise RuntimeError('owned native worker never consumed one CPU tick')
                time.sleep(.005)
            budget=ContinuationBudget(Path(directory),started_at=time.time(),max_actions=1,max_seconds=.05,max_bytes=10_000_000,max_memory_bytes=1_000_000_000,worker_memory_bytes=500_000_000,existing_bytes=0)
            try:
                with watchdog(budget):
                    try:
                        while worker.is_alive(): worker.join(timeout=.01)
                    finally:
                        if worker.is_alive(): worker.terminate()
                        worker.join()
            except BaseException as error:
                report['error']=type(error).__name__+': '+str(error)
            report.update(worker_still_alive_after_parent_cleanup=worker.is_alive(),worker_exitcode=worker.exitcode,worker_pid=str(worker.pid))
    finally:
        if worker.is_alive(): worker.kill()
        worker.join()
        report['after_own_emergency_cleanup_exitcode']=worker.exitcode
    print(json.dumps(report),flush=True)
