#!/usr/bin/env python3
"""Exercise saved boundary admission; never substitute finite evidence for Native.

Creates one genuine finite coupled-system RK4 fixture with actual QWork. Checks
its saved four-stage lineage, same-time evaluation/final distinction, and actual
metadata/byte mutations. Separately admits the ORIGINAL supplied Native t0 seed
and refuses an ORIGINAL supplied Native evaluation node. It does not propagate
Native physics or change producer files. Run only with explicit parent approval.

Usage: python run_mixed_energy_boundary_oracle.py --work-directory NEW_DIRECTORY
  --producer DIRECTORY --producer-owner-sha256 SHA --evaluation SAVED_NODE_JSON
  --cpus 6 7 8 --max-seconds 120

Prints a JSON report only after every assertion completes. The finite fixture
validates generic saved RK4 boundary machinery, not a material energy result.
"""
import argparse
from contextlib import ExitStack, contextmanager
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(HERE), str(HERE.parent/'0025'), str(HERE.parent/'0024')]
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'

from mixed_energy_saved_boundary import _Authority, _stage, admit_saved_boundary
from mixed_finite_coupled_system import CoupledFixture, FiniteDynamics
from mixed_response_rk4 import advance_step
from mixed_response_storage import COMPONENTS, MappedMixedState
from substrate_framework.partitioned_q_storage import QBudget
from substrate_framework.partitioned_q_work import QWork
from substrate_framework.streamed_material_state import file_binding


def require(condition, name, checks):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def refuses(action, name, checks):
    try:
        action()
    except (ValueError, FileNotFoundError):
        checks.append(name)
        return
    raise AssertionError(name+' was not refused')


@contextmanager
def changed_json(path, change):
    """Mutation scope is ONLY newly generated finite fixture metadata."""
    original = path.read_bytes()
    record = json.loads(original)
    change(record)
    path.write_text(json.dumps(record, allow_nan=False)+'\n')
    try:
        yield
    finally:
        path.write_bytes(original)


def inspect_finite_step(directory, initial, dt, identity):
    authority = _Authority()
    step_binding = authority.at(directory/'request.json')
    seed = authority.read(initial)
    all_outputs = []
    with ExitStack() as stack:
        base = stack.enter_context(MappedMixedState(initial))
        current, accumulator = base, None
        for stage in range(4):
            outputs = _stage(directory/f'stage-{stage}', step_binding=step_binding,
                stage=stage, base=base, current=current, accumulator=accumulator,
                dt=dt, identity=identity, seed=seed, authority=authority)
            all_outputs.append(outputs)
            if stage < 3:
                current = stack.enter_context(MappedMixedState(outputs['input']))
                accumulator = stack.enter_context(MappedMixedState(outputs['accumulator']))
    return all_outputs


def finite_checks(root, cpus, max_seconds, checks):
    fixture = CoupledFixture()
    budget = QBudget(max_actions=100000, max_seconds=max_seconds, max_bytes=512 << 20,
                     max_memory_bytes=3 << 30, worker_memory_bytes=1 << 30)
    sources = [file_binding(HERE/name) for name in (
        'mixed_finite_coupled_system.py', 'mixed_response_rk4.py',
        'mixed_response_edge_transition.py', 'mixed_response_storage.py',
        'mixed_energy_saved_boundary.py')]
    initial = fixture.initial(root/'initial', budget, sources)
    seed = json.loads(Path(initial['path']).read_bytes())
    dynamics = FiniteDynamics(fixture.system, root/'contexts', budget, sources)
    work = QWork(root/'qwork', budget, cpus, 'saved-boundary-genuine-finite-oracle')
    step = root/'step'
    dt = fixture.stop-fixture.start
    final = advance_step(initial, dt, dynamics=dynamics, work=work,
                         directory=step, identity=seed['identity'], budget=budget)
    outputs = inspect_finite_step(step, initial, dt, seed['identity'])
    require(outputs[-1]['final'] == final, 'genuine_four_stage_source_complete_endpoint', checks)
    evaluation = json.loads(Path(outputs[2]['input']['path']).read_bytes())
    physical = json.loads(Path(final['path']).read_bytes())
    require(evaluation['time'] == physical['time']
            and evaluation['kind'] == 'mixed-rk4-evaluation-node'
            and evaluation['provenance']['physical_endpoint'] is False
            and physical['kind'] == 'mixed-rk4-physical-endpoint'
            and physical['provenance']['physical_endpoint'] is True,
            'same_time_does_not_make_evaluation_node_physical', checks)
    require(not (root/'step-receipts').exists(), 'no_post_energy_driver_receipt_needed', checks)
    with MappedMixedState(final) as state:
        for index in range(len(state._shapes['mixed'])):
            for component in COMPONENTS:
                state.leg(component, index)
            state.release_edge(index)
    checks.append('genuine_endpoint_full_payloads_readable')
    inspect = lambda: inspect_finite_step(step, initial, dt, seed['identity'])
    with changed_json(step/'stage-3'/'complete.json', lambda r: r['transitions'].pop()):
        refuses(inspect, 'reject_partial_source_prefix', checks)
    with changed_json(step/'stage-3'/'complete.json', lambda r: r.update(complete=False)):
        refuses(inspect, 'reject_unfinished_stage3', checks)
    with changed_json(step/'stage-3'/'plan.json', lambda r: r.update(stage=2)):
        refuses(inspect, 'reject_changed_stage_plan_binding', checks)
    with changed_json(Path(final['path']), lambda r: r['small']['mixed']['p'][0].__setitem__(0, 999.)):
        refuses(inspect, 'reject_changed_endpoint_bytes', checks)
    payload = next(entry['path'] for entries in physical['legs'].values()
                   for entry in entries if 'path' in entry)
    payload_path = Path(payload)
    with payload_path.open('r+b') as stream:
        stream.seek(-1, os.SEEK_END)
        original = stream.read(1)
        stream.seek(-1, os.SEEK_END)
        stream.write(bytes([original[0] ^ 1]))
    try:
        def read_final():
            with MappedMixedState(final) as state:
                for index in range(len(state._shapes['mixed'])):
                    for component in COMPONENTS:
                        state.leg(component, index)
                    state.release_edge(index)
        refuses(read_final, 'reject_changed_original_payload_bytes', checks)
    finally:
        with payload_path.open('r+b') as stream:
            stream.seek(-1, os.SEEK_END)
            stream.write(original)
    return dict(initial=initial, final=final, observed_budget=budget.snapshot())


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--work-directory', type=Path, required=True)
    parser.add_argument('--producer', type=Path, required=True)
    parser.add_argument('--producer-owner-sha256', required=True)
    parser.add_argument('--evaluation', type=Path, required=True)
    parser.add_argument('--cpus', type=int, nargs='+', choices=range(6, 11), required=True)
    parser.add_argument('--max-seconds', type=float, required=True)
    args = parser.parse_args()
    if len(set(args.cpus)) != len(args.cpus) or not set(args.cpus) <= os.sched_getaffinity(0):
        raise ValueError('unique allocated CPUs6-10 required')
    root = args.work_directory.resolve()
    producer = args.producer.resolve()
    if root == producer or root.is_relative_to(producer):
        raise ValueError('oracle work must not be inside the original producer')
    root.mkdir(parents=True, exist_ok=False)
    checks = []
    initial = file_binding(producer/'initial'/'checkpoint.json')
    admission = admit_saved_boundary(producer, args.producer_owner_sha256, initial)
    require(admission['boundary_kind'] == 'initial'
            and admission['owner'] == json.loads((producer/'owner.json').read_bytes())
            and admission['state'] == json.loads(Path(initial['path']).read_bytes()),
            'actual_native_t0_original_typed_owner_state', checks)
    evaluation_binding = file_binding(args.evaluation)
    evaluation = json.loads(args.evaluation.read_bytes())
    require(args.evaluation.resolve().is_relative_to(producer)
            and evaluation['kind'] == 'mixed-rk4-evaluation-node',
            'actual_original_native_evaluation_metadata', checks)
    refuses(lambda: admit_saved_boundary(producer, args.producer_owner_sha256, evaluation_binding),
            'reject_actual_native_evaluation_node', checks)
    refuses(lambda: admit_saved_boundary(producer, '0'*64, initial), 'reject_changed_owner_digest', checks)
    refuses(lambda: admit_saved_boundary(producer, args.producer_owner_sha256,
            dict(initial, sha256='0'*64)), 'reject_changed_state_digest', checks)
    finite = finite_checks(root, tuple(args.cpus), args.max_seconds, checks)
    print(json.dumps(dict(status='passed', checks=checks, finite=finite,
        native_initial=initial, native_evaluation=evaluation_binding,
        scope='generic saved RK4 boundary and actual Native metadata only; no Native propagation or material energy result'),
        indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
