import datetime,hashlib,json,subprocess,sys,time
from pathlib import Path
config=json.loads(Path(sys.argv[1]).read_bytes()); root=Path(config['directory']); ops=Path(config['operations'])
result=dict(schema='P254-actual-current-mean-two-invocation-smoke-v1',status='failed',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phases=[])
print('P254_CURRENT_MEAN_'+'SMOKE_ARMED_002',flush=True)
try:
    for index,argv in enumerate(config['argvs']):
        began=time.time()
        completed=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=910)
        phase=dict(argv=argv,started_unix=began,finished_unix=time.time(),exit_code=completed.returncode,stdout=completed.stdout.decode(),stderr=completed.stderr.decode())
        (ops/('invocation-%d.json'%index)).write_text(json.dumps(phase,indent=2)+'\n')
        result['phases'].append(phase)
        print('ACTUAL_INVOCATION',index,'EXIT',completed.returncode,flush=True)
        if completed.returncode: raise RuntimeError('actual mean invocation failed; receipt retained')
        if index==0:
            original_owner=(root/'owner.json').read_bytes(); original_model=(root/'model.json').read_bytes()
    receipts=sorted(root.glob('invocations/*/receipt.json'))
    assert len(receipts)==2
    records=[json.loads(path.read_bytes()) for path in receipts]
    assert all(item['status']=='complete' and item['initial_contraction_reuse']['imported_complete_slots']==128 and item['budget']['hamiltonian_actions']==0 for item in records)
    assert len({item['original_started_unix'] for item in records})==1
    assert (root/'owner.json').read_bytes()==original_owner and (root/'model.json').read_bytes()==original_model
    result.update(status='passed',receipts=[dict(path=str(path),bytes=len(path.read_bytes()),sha256=hashlib.sha256(path.read_bytes()).hexdigest()) for path in receipts],owner_bytes_unchanged=True,model_bytes_unchanged=True,original_started_unix=records[0]['original_started_unix'],original_deadline_unix=records[0]['budget']['deadline_unix'],actual_cpu_choices=[item['cpus'] for item in records],new_hamiltonian_actions=0,all128_original_contractions_reused=True,scope='Actual current CLI and nonempty-directory resume, unchanged original model/owner/clock, original128-source reduction reuse. No new physical electronic work, control trajectory or comparison.')
except BaseException as error:
    result.update(error=type(error).__name__+': '+str(error))
finally:
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (ops/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('P254_CURRENT_MEAN_'+'SMOKE_DONE_002',result['status'],flush=True)
if result['status']!='passed': raise SystemExit(2)
