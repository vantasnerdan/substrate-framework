#!/usr/bin/env python3
"""Exercise context-only q pairs against independent finite matrix/Fock oracles."""
import argparse
from dataclasses import replace
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path[:0] = [str(ROOT/'src'), str(HERE)]
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[key] = '1'
import numpy as np
import sympy as sp

from run_joint_response_oracle import (FiniteSystem, DenseTangent, FockOracle,
    check, reject, CHECKS, pack_legs, unpack_legs)
from run_joint_partitioned_q_oracle import DiskFiniteHistory
from run_joint_q_material import encode
from substrate_framework.partitioned_q_response import PartitionedQResponse
from substrate_framework.partitioned_q_storage import QBudget
from substrate_framework.source_local_q_response import SourceLocalQResponse, prepare_pullback_frames
from substrate_framework.source_local_q_covariance import SourceLocalTwoSidedCovariance
from substrate_framework.source_local_q_state import next_coefficients
from substrate_framework.streamed_joint_covariance import initial_contraction
from substrate_framework.streamed_material_state import file_binding


def symbolic_reverse():
    h = sp.symbols('h', real=True)
    a = [sp.Matrix([[1+sp.I, 2], [-1, 0]]),
         sp.Matrix([[0, -sp.I], [2, 1]]), sp.Matrix([[2, 1+sp.I], [0, -1]])]
    eye, seed = sp.eye(2), sp.Matrix([1+sp.I, 2-sp.I])
    k0 = a[0]
    k1 = a[1]*(eye+h*k0/2)
    k2 = a[1]*(eye+h*k1/2)
    k3 = a[2]*(eye+h*k2)
    forward = eye+h*(k0+2*k1+2*k2+k3)/6
    current, out = h*seed/6, seed
    bad_current, bad_out = current, seed
    for stage, matrix in enumerate((a[2], a[1], a[1], a[0])):
        derivative, bad_derivative = matrix.H*current, matrix.H*bad_current
        out, bad_out = out+derivative, bad_out+bad_derivative
        if stage < 3:
            x, y = next_coefficients(stage, h)
            current = x*seed+y*derivative
            bad_current = x*seed+(h/2 if stage == 0 else y)*bad_derivative
    if any(sp.simplify(z) != 0 for z in out-forward.H*seed):
        raise AssertionError('noncommuting exact reverse graph differs')
    CHECKS.append(dict(name='symbolic_noncommuting_reverse_graph', passed=True, exact=True))
    witness = np.asarray((bad_out-forward.H*seed).subs(h, sp.Rational(1,5)), complex)
    check('wrong_first_reverse_chain_coefficient_sensitive', witness, np.zeros((2,1)), mutation=True)


def generator(response, system, time):
    size = len(pack_legs(response.zero_tangent()))
    return np.column_stack([pack_legs(response.rhs(system.stage(time), unpack_legs(response, column)))
                            for column in np.eye(size, dtype=complex)])


def forward_matrix(response, system, time, dt):
    a, b, c = (generator(response, system, t) for t in (time, time+dt/2, time+dt))
    eye = np.eye(len(a), dtype=complex)
    k0 = a
    k1 = b @ (eye+dt*k0/2)
    k2 = b @ (eye+dt*k1/2)
    k3 = c @ (eye+dt*k2)
    return eye+dt*(k0+2*k1+2*k2+k3)/6


def terminal(response, system, probe, time):
    stage = system.stage(time)
    ket, bra = [], []
    for i, edge in enumerate(response.edges):
        weight = response.sectors[edge.source].weight
        ket.append(weight*probe.actions[i](stage.frames[edge.source]))
        bra.append(weight*probe.adjoints[i](stage.frames[edge.target]).conj().T)
    return response.tangent(ket, bra, probe.u, probe.p, probe.coordinate, probe.momentum)


def exact_dual(response, system, probe, times):
    value = pack_legs(terminal(response, system, probe, times[-1]))
    for a, b in reversed(list(zip(times[:-1], times[1:]))):
        value = forward_matrix(response, system, a, b-a).conj().T @ value
    return unpack_legs(response, value)


def exercise(system, gamma, unequal, directory, budget, cpus):
    r = system.response(gamma)
    tag = ('Gamma' if gamma else 'directed-rectangular-q')+('-unequal-weights' if unequal else '')
    if unequal:
        r.sectors = tuple(replace(sector, weight=weight)
                          for sector, weight in zip(r.sectors, (.2, .5, .3)))
    dense = DenseTangent(system, r)
    left = dense.probe(system.random((dense.size,)), tag+'-A')
    right = dense.probe(system.random((dense.size,)), tag+'-B')
    history = DiskFiniteHistory(system, r, budget)
    executor = PartitionedQResponse(r, history, kernel_adjoint=lambda n, **kw: system.k*n,
        grid_measure=1., budget=budget, directory=directory/'executor', identity=tag,
        cpus=cpus, work_directory=directory/'physical-work')
    from substrate_framework.joint_ordered_sources import JointProductPreparation
    preparation = JointProductPreparation(r, system.stage(0), ionic_ordered=system.wi,
        ionic_minus_ordered=system.wi, field_ordered=system.wf if gamma else np.zeros((0,0)),
        electronic_identity='original-raw-singular-D', ionic_identity='original-ionic-W',
        field_identity='original-global-field-W', product_identity='original-product')
    grids = (np.array([0., .003, .009]), np.array([0., .004]))
    prepare_pullback_frames(executor, grids)
    states, expected = [], []
    for side, probe, grid in zip(('left', 'right'), (left, right), grids):
        state = SourceLocalQResponse(executor, directory/'pair'/side).pullback(probe, grid)
        reference = exact_dual(r, system, probe, grid)
        check(tag+'_'+side+'_full_rectangular_discrete_dual', pack_legs(state), pack_legs(reference), tolerance=2e-11)
        states.append(state)
        expected.append(reference)
    reference = initial_contraction(preparation, *expected)
    covariance = SourceLocalTwoSidedCovariance(preparation, executor)
    actual = covariance.pair(left, right, *grids, directory/'pair')
    for ordering in ('AB', 'BA'):
        for origin in ('electronic', 'ionic', 'field', 'total'):
            check(tag+'_'+ordering+'_'+origin, actual[ordering][origin], reference[ordering][origin], tolerance=2e-11)
    for item in ('commutator', 'symmetrized'):
        check(tag+'_'+item, actual[item], reference[item], tolerance=2e-11)
    check(tag+'_raw_compatibility_preserved',
        [[x['left'], x['right']] for x in actual['raw_frame_compatibility']],
        [[x['left'], x['right']] for x in reference['raw_frame_compatibility']], tolerance=2e-11)
    b0 = terminal(r, system, right, 0.)
    check(tag+'_genuine_second_pullback_sensitive', initial_contraction(preparation, expected[0], b0)['AB']['total'],
          actual['AB']['total'], mutation=True)
    if not unequal:
        fock = FockOracle(system)
        pa, pb = dense.pullback(grids[0][-1], left), dense.pullback(grids[1][-1], right)
        for ordering in ('AB', 'BA'):
            for origin, value in fock.parts(r, pa, pb, ordering).items():
                check(tag+'_independent_Fock_'+ordering+'_'+origin,
                      actual[ordering][origin], value, tolerance=2e-8)
    prepare_pullback_frames(executor, grids)
    restored = SourceLocalQResponse(executor, directory/'pair'/'left').restore(left, grids[0], actual['left_context'])
    check(tag+'_restored_source_context', pack_legs(restored), pack_legs(expected[0]), tolerance=2e-11)
    reject(tag+'_foreign_probe_context_refused', lambda: SourceLocalQResponse(
        executor, directory/'pair'/'left').restore(right, grids[0], actual['left_context']))
    record = json.loads(Path(actual['left_context']['path']).read_text())
    context = record['intervals'][0]['contexts'][0]
    path = Path(context['path'])
    original = path.read_bytes()
    path.write_bytes(original+b' ')
    try:
        reject(tag+'_changed_context_digest_refused', lambda: SourceLocalQResponse(
            executor, directory/'pair'/'left').restore(left, grids[0], actual['left_context']))
    finally:
        path.write_bytes(original)
    electronic_payloads = list((directory/'pair').glob('**/ket.npy'))+list((directory/'pair').glob('**/bra.npy'))
    if electronic_payloads:
        raise AssertionError('source-local propagation retained electronic payloads')
    CHECKS.append(dict(name=tag+'_actual_payload_inventory', passed=True,
        payloads=[str(p.relative_to(directory)) for p in (directory/'pair').glob('**/*.npy')],
        result_binding=actual['context_pair_binding']))
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cpus', nargs='+', type=int, default=[6])
    args = parser.parse_args()
    os.sched_setaffinity(0, {args.cpus[0]})
    args.work.mkdir(parents=True, exist_ok=False)
    budget = QBudget(max_actions=1000000, max_seconds=300, max_bytes=128000000,
                     max_memory_bytes=4000000000, worker_memory_bytes=1000000000)
    result = dict(schema='P254-source-local-q-oracle-v1', status='failed', checks=CHECKS,
        sources=[file_binding(ROOT/'src/substrate_framework'/name) for name in
                 ('source_local_q_state.py', 'source_local_q_response.py', 'source_local_q_covariance.py')],
        scientific_scope='Finite moving examples only; not an actual material-noise result or a production disk-fit claim')
    try:
        symbolic_reverse()
        system = FiniteSystem()
        for gamma, unequal, name in ((True, False, 'Gamma'), (False, False, 'directed'), (True, True, 'weighted')):
            exercise(system, gamma, unequal, args.work/name, budget, args.cpus)
        result['status'] = 'passed'
    except Exception as error:
        result['error'] = type(error).__name__+': '+str(error)
    result['budget'] = budget.snapshot()
    result['measured_file_bytes'] = sum(p.stat().st_size for p in args.work.rglob('*') if p.is_file())
    with args.output.open('x') as stream:
        json.dump(encode(result), stream, indent=2, allow_nan=False)
        stream.write('\n')
    if result['status'] != 'passed':
        raise SystemExit(2)


if __name__ == '__main__':
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=1):
        main()
